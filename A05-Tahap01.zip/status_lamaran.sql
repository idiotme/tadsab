INSERT INTO STATUS_LAMARAN (id, status) VALUES ('1', 'melamar');
INSERT INTO STATUS_LAMARAN (id, status) VALUES ('2', 'direkomendasikan');
INSERT INTO STATUS_LAMARAN (id, status) VALUES ('3', 'diterima');
INSERT INTO STATUS_LAMARAN (id, status) VALUES ('4', 'ditolak');