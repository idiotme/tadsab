INSERT INTO TERM (tahun, semester) VALUES (2015, 1);
INSERT INTO TERM (tahun, semester) VALUES (2015, 2);
INSERT INTO TERM (tahun, semester) VALUES (2015, 3);
INSERT INTO TERM (tahun, semester) VALUES (2016, 1);
INSERT INTO TERM (tahun, semester) VALUES (2016, 2);
INSERT INTO TERM (tahun, semester) VALUES (2016, 3);