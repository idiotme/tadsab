INSERT INTO STATUS_LOG (id, status) VALUES ('1', 'dilaporkan');
INSERT INTO STATUS_LOG (id, status) VALUES ('2', 'disetujui');
INSERT INTO STATUS_LOG (id, status) VALUES ('3', 'ditolak');
INSERT INTO STATUS_LOG (id, status) VALUES ('4', 'diproses');