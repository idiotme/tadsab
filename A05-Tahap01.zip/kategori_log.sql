INSERT INTO KATEGORI_LOG (id, kategori) VALUES ('1', 'asistensi/tutorial');
INSERT INTO KATEGORI_LOG (id, kategori) VALUES ('2', 'persiapan asistensi');
INSERT INTO KATEGORI_LOG (id, kategori) VALUES ('3', 'membuat soal/tugas');
INSERT INTO KATEGORI_LOG (id, kategori) VALUES ('4', 'rapat');
INSERT INTO KATEGORI_LOG (id, kategori) VALUES ('5', 'sit in kelas');
INSERT INTO KATEGORI_LOG (id, kategori) VALUES ('6', 'mengoreksi');
INSERT INTO KATEGORI_LOG (id, kategori) VALUES ('7', 'mengawas');