<?php
	/*$dbhost = "localhost";
	$dbuser = "postgres";
	$dbpass = "postgres";*/

	$host        = "dbpg.cs.ui.ac.id";
	$dbuser		 = "a05";
	$dbpass		 = "nRH4gt";
?>	