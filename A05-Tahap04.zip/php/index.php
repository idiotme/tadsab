<<<<<<< HEAD
<<<<<<< HEAD
<?php 

echo "login berhasil yeay.";
echo " <a href='logout.php'>logout</a> ";
echo $_GET['id']." yehey";
=======
<?php
	header("Location: login.php");
>>>>>>> 6e4adb03b39b5e4b37cf330fb9f6886b2359ed86
=======
<?php
	header("Location: login.php");
>>>>>>> 6e4adb03b39b5e4b37cf330fb9f6886b2359ed86
?>