<?php
	$dbhost = "localhost";
	$dbuser = "postgres";
	$dbpass = "postgres";
?>	